package tesoem.edu.mx.itics.p27t2122;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView text_Respuesta;

    private EditText edit_Num1;
    private EditText edit_Num2;

    @SuppressLint({"MissingInflatedId", "SetTextI18n"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        text_Respuesta = findViewById(R.id.Respuesta);

        edit_Num1 = findViewById(R.id.Num1);
        edit_Num2 = findViewById(R.id.Num2);


        Button btn_suma;
        btn_suma = findViewById(R.id.button_suma);
        btn_suma.setOnClickListener(v -> text_Respuesta.setText( suma( Integer.parseInt(edit_Num1.getText().toString()),Integer.parseInt(edit_Num2.getText().toString()) )+""));


        Button btn_division = findViewById(R.id.button_division);
        btn_division.setOnClickListener(v -> text_Respuesta.setText( division( Integer.parseInt(edit_Num1.getText().toString()),Integer.parseInt(edit_Num2.getText().toString()) )+""));

        Button btn_multiplicacion = findViewById(R.id.button_multiplicacion);
        btn_multiplicacion.setOnClickListener(v -> text_Respuesta.setText( multiplicacion( Integer.parseInt(edit_Num1.getText().toString()),Integer.parseInt(edit_Num2.getText().toString()) )+""));

        Button btn_resta = findViewById(R.id.button_resta);
        btn_resta.setOnClickListener(v -> text_Respuesta.setText( resta( Integer.parseInt(edit_Num1.getText().toString()),Integer.parseInt(edit_Num2.getText().toString()) )+""));

    }

    public double suma (int a, int b){
        return a+b;
    }

    public double resta (int a, int b){
        return a-b;
    }

    public double multiplicacion (int a, int b){
        return a*b;
    }

    public double division (int a, int b){
        int Respuesta = 0;

        if (b!=0){
            Respuesta=a/b;
        }

        return Respuesta;

    }
}